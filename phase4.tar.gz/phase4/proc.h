// proc.h, 159
// Team Evo

#ifndef _PROC_H_
#define _PROC_H_

int print_semaphore;

void Idle();
void UserProc();
void PrintDriver();

#endif
