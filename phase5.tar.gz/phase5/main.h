// main.h, 159
// team: evo
#ifndef _MAIN_H_
#define _MAIN_H_

#include "type.h"

int main();
void InitData();
void SelectCRP();
void Kernel();

#endif
