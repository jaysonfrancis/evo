// proc.h, 159
// Team Evo

#ifndef _PROC_H_
#define _PROC_H_

void Idle();
void UserProc();
void Producer();
void Consumer();

#endif
